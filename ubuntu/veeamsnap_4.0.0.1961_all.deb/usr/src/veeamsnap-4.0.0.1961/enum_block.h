#pragma once

void enum_block_print_state(void);

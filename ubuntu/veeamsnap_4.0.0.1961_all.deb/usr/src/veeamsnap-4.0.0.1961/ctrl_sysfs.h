#pragma once

int ctrl_sysfs_init(struct device **p_device);
void ctrl_sysfs_done(struct device **p_device);
